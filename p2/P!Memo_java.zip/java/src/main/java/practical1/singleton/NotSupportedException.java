package practical1.singleton;

public class NotSupportedException extends Throwable {

}
